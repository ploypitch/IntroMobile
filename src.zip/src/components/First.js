import React from 'react';
//import SignIn from '../components/SignIn';
//import Reg from '../components/Register';
import TabSR from '../components/tabSignReg'

export default class First extends React.Component {

    render() {
      return (
        <div>
          <TabSR />
          
        </div>
      );
    }
  }
  